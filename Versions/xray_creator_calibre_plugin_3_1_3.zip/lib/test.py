import re


def _get_paragraph_data(codec):
    with open('book.html') as f:
        book_html = f.read()

    paragraph_data = []
    for node in re.finditer(PARAGRAPH_PAT, book_html):
        word_loc = {'words': '', 'locs': [], 'char_sizes': []}

        skip = False
        loc = node.start(0)
        for i, char in enumerate(node.group(0).decode(codec)):
            word_loc['char_sizes'].append(len(char.encode(codec)))
            if char == '<' and not skip:
                skip = True
                if node.group(0)[i:i+3] == '<br':
                    word_loc['words'] += ' '
                    word_loc['locs'].append(loc)
            if not skip:
                word_loc['words'] += char
                word_loc['locs'].append(loc)
            if char == '>' and skip:
                skip = False
            loc += len(char.encode(codec))

        if len(word_loc['locs']) > 0:
            paragraph_data.append((word_loc, node.start(0), len(node.group(0))))

    return paragraph_data

def _process_match(match, codec, word_loc):
    start =_find_start(match.start(0), word_loc)
    length = _find_len_word(match.start(0), match.end(0), word_loc)
    print 'start', start
    print 'length', length
    for i, char in enumerate(word_loc['words']):
        if i >= start and i < start + length:
            print char.encode(codec), word_loc['char_sizes'][i]

def _find_start(start, word_loc):
    '''Finds beggining index of word'''
    string = word_loc['words']
    char_sizes = word_loc['char_sizes']

    previous_space = string[:start].rfind(' ')
    if previous_space == -1:
        start_index = 0
    else:
        start_index = previous_space + 1

    return sum(char_sizes[:start+1])
    return start_index

def _find_len_word(start, end, word_loc):
    '''Finds length between starting index of word and the next space'''
    string = word_loc['words']
    char_sizes = word_loc['char_sizes']

    first_char = string[:start].rfind(' ')
    last_char = string.find(' ', end)

    if first_char == -1:
        first_char = 0
    else:
        first_char += 1
    if last_char == -1:
        last_char = len(string) - 1
    else:
        last_char -= 1

    total_len = sum(char_sizes[start:last_char+1])
    return total_len


codec = 'utf8'
words = ['Armansky']
escaped_word_list = [re.escape(word) for word in words]
PARAGRAPH_PAT = re.compile(r'<(p|i|h\d) .*?>.+?(?:<\/\1)', re.I)
word_pat = re.compile(r'(\b' + r'\b|\b'.join(escaped_word_list) + r'\b)', re.I)

for word_loc, para_start, para_len in _get_paragraph_data(codec):
    for match in re.finditer(word_pat, word_loc['words']):
        entity_id = _process_match(match, codec, word_loc)